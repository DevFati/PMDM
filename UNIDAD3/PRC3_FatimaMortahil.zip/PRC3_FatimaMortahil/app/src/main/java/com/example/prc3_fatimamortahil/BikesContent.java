package com.example.prc3_fatimamortahil;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class BikesContent {

    public static List<Bike> ITEMS = new ArrayList<>();
    public static String selectedDate;

    public static void loadBikesFromJSON(Context context) {
        try {
            InputStream is = context.getAssets().open("bikeList.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            String json = new String(buffer, "UTF-8");
            JSONObject jsonObject = new JSONObject(json);
            JSONArray bikesArray = jsonObject.getJSONArray("bike_list");

            for (int i = 0; i < bikesArray.length(); i++) {
                JSONObject bikeObject = bikesArray.getJSONObject(i);
                String owner = bikeObject.getString("owner");
                String description = bikeObject.getString("description");
                String city = bikeObject.getString("city");
                String location = bikeObject.getString("location");
                String email = bikeObject.getString("email");

                Bitmap photo = BitmapFactory.decodeStream(context.getAssets().open("images/" + bikeObject.getString("image")));
                ITEMS.add(new Bike(photo, owner, description, city, location, email));
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
    }

    public static class Bike {
        public Bitmap photo;
        public String owner;
        public String description;
        public String city;
        public String location;
        public String email;

        public Bike(Bitmap photo, String owner, String description, String city, String location, String email) {
            this.photo = photo;
            this.owner = owner;
            this.description = description;
            this.city = city;
            this.location = location;
            this.email = email;
        }
    }
}

