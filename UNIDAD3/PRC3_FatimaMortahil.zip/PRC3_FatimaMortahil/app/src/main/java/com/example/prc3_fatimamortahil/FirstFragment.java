package com.example.prc3_fatimamortahil;

import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class FirstFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        CalendarView calendarView = view.findViewById(R.id.calendarView);
        TextView textViewFecha = view.findViewById(R.id.textViewFechaSeleccionada);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String fecha = dayOfMonth + "/" + (month + 1) + "/" + year;
                textViewFecha.setText("Fecha seleccionada: " + fecha);
                BikesContent.selectedDate = fecha; // Almacena la fecha seleccionada
            }
        });

        return view;
    }
}

