package com.example.prc3_fatimamortahil;


import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class SecondFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_second, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        BikesContent.loadBikesFromJSON(getContext());
        MyItemRecyclerViewAdapter adapter = new MyItemRecyclerViewAdapter(BikesContent.ITEMS);
        recyclerView.setAdapter(adapter);

        return view;
    }
}

