package com.example.prc3_fatimamortahil;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private EditText editTextDireccion;
    private EditText editTextEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Referencias a los EditText
        editTextDireccion = findViewById(R.id.editTextDireccion);
        editTextEmail = findViewById(R.id.editTextEmail);

        // Botón de Login
        Button btnLogin = findViewById(R.id.buttonLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validarDatos()) {
                    Intent intent = new Intent(MainActivity.this, BikeActivity.class);
                    startActivity(intent);
                }
            }
        });
    }

    /**
     * Validación de los datos ingresados en EditText
     */
    private boolean validarDatos() {
        String direccion = editTextDireccion.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();

        if (direccion.isEmpty()) {
            editTextDireccion.setError("La dirección no puede estar vacía");
            return false;
        }

        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Ingresa un correo electrónico válido");
            return false;
        }

        return true;
    }
}
