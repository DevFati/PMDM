package com.example.prc3_fatimamortahil;


import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MyItemRecyclerViewAdapter extends RecyclerView.Adapter<MyItemRecyclerViewAdapter.ViewHolder> {

    private final List<BikesContent.Bike> bikes;

    public MyItemRecyclerViewAdapter(List<BikesContent.Bike> items) {
        bikes = items;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BikesContent.Bike bike = bikes.get(position);

        holder.textViewOwner.setText(bike.owner);
        holder.textViewDescription.setText(bike.description);
        holder.imageViewPhoto.setImageBitmap(bike.photo);

        holder.buttonEmail.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:" + bike.email));
            intent.putExtra(Intent.EXTRA_SUBJECT, "Solicitud para usar tu bicicleta");
            intent.putExtra(Intent.EXTRA_TEXT, "Hola " + bike.owner + ", me gustaría usar tu bicicleta.");
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return bikes.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public final ImageView imageViewPhoto;
        public final TextView textViewOwner;
        public final TextView textViewDescription;
        public final Button buttonEmail;

        public ViewHolder(View view) {
            super(view);
            imageViewPhoto = view.findViewById(R.id.imageViewBike);
            textViewOwner = view.findViewById(R.id.textViewOwner);
            textViewDescription = view.findViewById(R.id.textViewDescription);
            buttonEmail = view.findViewById(R.id.buttonEmail);
        }
    }
}
